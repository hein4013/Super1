<?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$city=$_POST['t4'];

if(mysql_query("insert into register(name,email,password,city) values('$name','$email','$password','$city')"))
{
//echo "<script>location.href='reg_success.php?email=$email'</script>"; 
header("location:reg_success.php?name=$name & email=$email");}
else {$error= "user already exists";}}

?>
<html>
<body background="img/login.jpg">
<center>
<br><br><br><br><br><br><br><br><br><br>
<form method="post">
<table border="2" width="300" height="325" cellspacing="0" bgcolor="#80c0f2">
<tr>
<td align="center" colspan="2">Registration form</td>
</tr>
<tr>
<td height="26" align="center">Name:</td>
<td align="center"><input type="text" name="t1" autofocus placeholder="Mr.exmaple" required>(*)</td>
</tr>
<tr>
<td height="29" align="center">Email:</td>
<td align="center"><input type="email" name="t2"  placeholder="example@gmail.com" required>(*)</td>
</tr>
<tr>
<td height="33" align="center">Password:</td>
<td align="center"><input type="password" name="t3"  placeholder="1@3eD"></td>
</tr>
<tr>
<td height="167" align="center">Address:</td>
<td align="center"><textarea rows="5" cols="20" name="t4"></textarea></td>
</tr>
<tr>
<td height="28" colspan="2" align="center"><input type="submit" name="sub" value="submit"></td>
</tr>
</table>
</form>
</center>
</body>
</html>