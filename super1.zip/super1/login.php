<?php
session_start();
error_reporting(1);
include("connection.php");
if(isset($_POST['log']))
{ if($_POST['id']=="" || $_POST['pwd']=="")
{ $err="fill your id and password first"; }
else 
{$d=mysql_query("select * from register where email='{$_POST['id']}' ");
$row=mysql_fetch_object($d);
$fid=$row->email;
$fpass=$row->password; 
if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
{$_SESSION['sid']=$_POST['id'];
//echo"<script>location:href='order.php'</script>";
header("location:order.php"); 
}
else {$err=" your password is not"; }}
}
?>

<html>
<body background="img/login.jpg">
<center>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
<form method="post">
<table border="2" width="400" height="280" cellspacing="1" bgcolor="#2296C9"  >
<tr><td colspan="2"><?php echo $err; ?></td></tr>
<tr>
<td height="50" colspan="2" align="center">Login Page</td>
</tr>
<tr>
<td height="38" align="center" >Email:</td>
<td align="center"><input type="email" name="id" autofocus placeholder="example@gmail.com">
</tr>
<tr>
<td height="49" align="center">Password:</td>
<td align="center"><input type="password" name="pwd" autofocus placeholder="123456">
</tr>
<tr>
<td height="33" colspan="2" align="center"><input type="submit" name="log" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="signin.php">Sign in</a></td>
</tr>
</table>
</form>
</center>
</body>
</html>



